package com.cg.lab1.fourth;

public interface EmployeeService {
public Employee getDetails(int empId);
}
