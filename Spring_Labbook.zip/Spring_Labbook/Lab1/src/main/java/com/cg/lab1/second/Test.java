package com.cg.lab1.second;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring2.xml");
		Employee emp=context.getBean("emp",Employee.class);
		System.out.println("Employee Details");
		System.out.println("-------------------------");
		System.out.println("Employee \n{\nempAge="+emp.getAge()+", \nempId="+emp.getEmployeeId()+", \nempName="+emp.getEmployeeName()+", \nempSalary="+emp.getSalary()+"\n}");
		System.out.println("\n\nSBU details");
		System.out.println("-------------------------");
		System.out.println("Sbu details=SBU \n{\nsbuCode="+emp.getBusinessUnit().getSbuName()+", \nsbuHead="+emp.getBusinessUnit().getSbuHead()+", \nsbuName="+emp.getBusinessUnit().getSbuName()+"\n}");		
	}
}
