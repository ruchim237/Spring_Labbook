package com.capg.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.NOT_ACCEPTABLE,reason="Invalid Credentials")
public class InvalidLogin extends RuntimeException {

	
	public InvalidLogin() {
		super();
		
	}

	

}
