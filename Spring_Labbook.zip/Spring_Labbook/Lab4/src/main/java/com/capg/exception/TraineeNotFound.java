package com.capg.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Trainee Id is Unavailable")
public class TraineeNotFound extends RuntimeException {

	public TraineeNotFound() {
		super();
	}

	
}
